import "GoldbishopsPlugins.OneBigBag";

OneBigBag = OneBigBagWindow();
